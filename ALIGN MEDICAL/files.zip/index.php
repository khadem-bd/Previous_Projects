<!DOCTYPE html>
<html lang="en">
<?php include "bundle.php"; ?>
<body>
    <section class="banner"></section>
    <section class="content">
        <div class="container">
            <img class="logo" src="images/logo.svg" alt="">
            <h1>coming soon</h1>
            <p>website under construction</p>
        </div>
    </section>

    <div class="container">
        <footer>
            <ul class="social-icon">
                <li><a target="_blank" href="https://www.instagram.com/ALIGNMEDICALMGT/"><span class="icon-instagram icon"></span></a></li>
                <li><a target="_blank" href="https://www.facebook.com/profile.php?id=100091398848794"><span class="icon-facebook icon"></span></a></li>
                <li><a target="_blank" href="https://twitter.com/ALIGNMEDICALMGT"><span class="icon-twitter icon"></span></a></li>
                <li><a target="_blank" href="https://www.linkedin.com/company/alignmedicalmgt/"><span class="icon-linkedin icon"></span></a></li>
            </ul>
        </footer>
    </div>
</body>
</html>